<?php
print"
     __                ___  _________
 __ / /__  ___  __ _  / _ \/ ___/ __/
/ // / _ \/ _ \/  ' \/ , _/ /__/ _/  
\___/\___/\___/_/_/_/_/|_|\___/___/  
           By Psyco & AnonJocker
  ";
error_reporting(0);
set_time_limit(0);
if(!file_exists($argv[1])){
  die('List Sites Not Found');
}
$get=file_get_contents($argv[1]);
$ex=explode("\n",$get);
$c=file($argv[1]);
echo"Total target : ".count($c)."\n\n";
foreach($c as $sites){
   $sites=trim($sites);
$dir ="/Mah.html";
$file = @file_get_contents($sites.$dir);
	 if (eregi('Mahfoud', $file)) {
print "$sites/k.html\n";
$f = fopen("Mah.html","a+");
	 fwrite($f , "$sites/Mah.html<br>"); 
	 fclose($f);
	 continue;
} }
?>